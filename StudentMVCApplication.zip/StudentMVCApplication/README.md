# Student MVC Application - Preview

This is a single-file, beginner-friendly preview of a Java MVC Full Stack application.

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome, or use VS Code Live Server.
3. Try adding and deleting students.

## MVC learning map
- View -> HTML/CSS/JavaScript
- Controller -> JavaScript functions in this preview
- Model -> Student objects
- Service -> business logic concept
- Repository/Database -> represented conceptually

Next step: convert this preview into Spring Boot MVC + MySQL + JPA.
